import sys

# import dis
from cProfile import Profile
import pstats

from subprocess import Popen
from sciscrape.config import config
from sciscrape.fetch import SciScraper

from memory_profiler import profile


def run_benchmark(args, sciscrape: SciScraper) -> None:
    with Profile() as pr:
        sciscrape(args.file, args.export, args.debug)
    stats = pstats.Stats(pr)
    stats.sort_stats(pstats.SortKey.TIME)
    stats.print_stats()
    stats.dump_stats(config.profiling_path)
    Popen([sys.executable, "-m", "snakeviz", config.profiling_path])


@profile(precision=4)
def run_memory_profiler(args, sciscrape: SciScraper) -> None:
    sciscrape(args.file, args.export, args.debug)


"""
TODO: def run_disassembler(args, sciscrape: SciScraper) -> None:
    dis.dis(sciscrape(args.file, args.export, args.debug))
"""
